import 'dart:convert';
import 'package:http/http.dart' as http;

class GroqService {
  static const String apiKey = "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";
  static const String url = "https://api.groq.com/openai/v1/chat/completions";

  static Future<String> askGroq(String prompt) async {
    try {
      final res = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $apiKey',
        },
        body: jsonEncode({
          "model": "openai/gpt-oss-20b",
          "messages": [
            {"role": "system", "content": "You are Trading Auto Assistant, anime girl AI. Give short signal: UP or DOWN for EUR/USD with reason."},
            {"role": "user", "content": prompt}
          ]
        }),
      ).timeout(Duration(seconds: 20));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data['choices'][0]['message']['content'];
      } else {
        return "Groq Error ${res.statusCode}: ${res.body}";
      }
    } catch (e) {
      return "Boss, Groq se connect nahi ho raha. Error: $e";
    }
  }
}
