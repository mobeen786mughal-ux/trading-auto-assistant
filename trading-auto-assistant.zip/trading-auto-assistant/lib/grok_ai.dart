import 'dart:convert';
import 'package:http/http.dart' as http;

class GrokAI {
  final String apiKey = "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";

  Future<String> ask(String msg) async {
    try {
      final res = await http.post(
        Uri.parse("https://api.x.ai/v1/chat/completions"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $apiKey",
        },
        body: jsonEncode({
          "model": "grok-beta",
          "messages": [
            {"role": "system", "content": "Tum Trading Auto Assistant ho. Roman Urdu me short jawab do. EUR/USD expert ho."},
            {"role": "user", "content": msg}
          ],
        }),
      );
      var data = jsonDecode(res.body);
      return data['choices'][0]['message']['content'];
    } catch (e) {
      return "Boss, Grok se connect nahi ho raha.";
    }
  }
}
