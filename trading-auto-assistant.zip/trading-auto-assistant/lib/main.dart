import 'package:flutter/material.dart';
import 'grok_ai.dart';
import 'trading_bot.dart';
import 'floating_dot.dart';

void main() { runApp(TradingAutoAssistant()); }

class TradingAutoAssistant extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: HomeScreen());
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  GrokAI grok = GrokAI();
  TradingBot bot = TradingBot();
  String aiReply = "Boss, main aa gaya. Bol, kaunsi trade lagani hai?";

  void askAI() async {
    setState(() { aiReply = "Soch raha hun boss..."; });
    String reply = await grok.ask("EUR/USD ka kya scene hai? UP ya DOWN?");
    setState(() { aiReply = reply; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Column(
            children: [
              SizedBox(height: 60),
              Text("TRADING AUTO ASSISTANT", style: TextStyle(color: Colors.blue, fontSize: 20, fontWeight: FontWeight.bold)),
              Container(
                margin: EdgeInsets.all(16),
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(20)),
                child: Column(children: [
                  Text("Demo Balance", style: TextStyle(color: Colors.white70)),
                  Text("\$${bot.balance.toStringAsFixed(2)}", style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                    Text("Win: ${bot.wins}", style: TextStyle(color: Colors.green)),
                    Text("Loss: ${bot.losses}", style: TextStyle(color: Colors.red)),
                  ]),
                ]),
              ),
              Container(
                margin: EdgeInsets.all(16),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.blue.withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.blue)),
                child: Column(children: [
                  CircleAvatar(radius: 35, backgroundColor: Colors.blue, child: Icon(Icons.smart_toy, size: 40, color: Colors.white)),
                  SizedBox(height: 10),
                  Text(aiReply, textAlign: TextAlign.center, style: TextStyle(color: Colors.white)),
                  SizedBox(height: 15),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                    ElevatedButton(onPressed: askAI, child: Text("Analyse")),
                    ElevatedButton(onPressed: () { setState(() { aiReply = bot.trade("EUR/USD", "UP"); }); }, child: Text("UP"), style: ElevatedButton.styleFrom(backgroundColor: Colors.green)),
                    ElevatedButton(onPressed: () { setState(() { aiReply = bot.trade("EUR/USD", "DOWN"); }); }, child: Text("DOWN"), style: ElevatedButton.styleFrom(backgroundColor: Colors.red)),
                  ]),
                ]),
              ),
            ],
          ),
          Positioned(bottom: 30, right: 20, child: FloatingDot(onTap: askAI)),
        ],
      ),
    );
  }
}
