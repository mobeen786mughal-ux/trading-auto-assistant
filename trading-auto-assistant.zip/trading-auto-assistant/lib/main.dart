import 'package:flutter/material.dart';
import 'groq_service.dart';

void main() => runApp(const TradingApp());

class TradingApp extends StatelessWidget {
  const TradingApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: const Color(0xFF0F0F1A)),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double balance = 100.0;
  int wins = 0, losses = 0;
  String aiMsg = "Boss, main ready hun! Analyse dabao.";
  bool isAnalysing = false;
  String lastSignal = "";

  Future<void> analyse() async {
    setState(() { isAnalysing = true; aiMsg = "Groq se pooch rahi hun..."; });
    final res = await GroqService.askGroq("Give EUR/USD signal UP or DOWN for next 1 min, with short reason.");
    setState(() { aiMsg = res; isAnalysing = false; });
  }

  void trade(String dir) {
    bool win = (lastSignal == dir) || (aiMsg.toUpperCase().contains(dir));
    setState(() {
      if (aiMsg.toUpperCase().contains("UP") || aiMsg.toUpperCase().contains("DOWN")) {
        if (win) { balance += 0.80; wins++; } else { balance -= 1.0; losses++; }
      } else {
        balance += 0.0;
      }
      aiMsg = win ? "Boss, WIN! 🎉 Balance: \$${balance.toStringAsFixed(2)}" : "Boss, LOSS. Next wala pakka! Balance: \$${balance.toStringAsFixed(2)}";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Trading Auto Assistant"), backgroundColor: const Color(0xFF1A1A2E), centerTitle: true),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset("assets/anime_girl.png", height: 220, width: double.infinity, fit: BoxFit.cover, errorBuilder: (c,e,s) => Container(height: 220, color: Colors.pinkAccent.withOpacity(0.2), child: const Icon(Icons.person, size: 100, color: Colors.pink))),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(16)),
              child: Column(children: [
                const Text("Demo Balance", style: TextStyle(color: Colors.grey)),
                Text("\$${balance.toStringAsFixed(2)}", style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.green)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  Text("Win: $wins", style: const TextStyle(color: Colors.green)),
                  Text("Loss: $losses", style: const TextStyle(color: Colors.red)),
                ]),
              ]),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity, padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.purple.withOpacity(0.15), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.purple)),
              child: Text(aiMsg, style: const TextStyle(fontSize: 15)),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: isAnalysing ? null : analyse,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple, minimumSize: const Size(double.infinity, 50)),
              child: Text(isAnalysing ? "Analysing..." : "✨ Analyse with Groq"),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: ElevatedButton(onPressed: () => trade("UP"), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, minimumSize: const Size(0, 60)), child: const Text("UP 📈", style: TextStyle(fontSize: 20)))),
              const SizedBox(width: 12),
              Expanded(child: ElevatedButton(onPressed: () => trade("DOWN"), style: ElevatedButton.styleFrom(backgroundColor: Colors.red, minimumSize: const Size(0, 60)), child: const Text("DOWN 📉", style: TextStyle(fontSize: 20)))),
            ]),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: analyse,
        backgroundColor: Colors.purple,
        child: const Icon(Icons.bolt),
      ),
    );
  }
}
