class TradingBot {
  double balance = 100.0;
  int wins = 0;
  int losses = 0;
  bool isOn = false;

  String trade(String pair, String direction) {
    if (direction == "UP") {
      wins++;
      balance += 1.8;
      return "Boss, $pair pe UP laga di. Jeet gaye! +\$1.80";
    } else {
      losses++;
      balance -= 1.0;
      return "Boss, $pair pe DOWN laga di. Haar gaye, agli me cover karte hain.";
    }
  }

  String analyse() {
    return "Boss, EUR/USD upar ja raha hai. 1 min wali UP safe lag rahi hai.";
  }
}
