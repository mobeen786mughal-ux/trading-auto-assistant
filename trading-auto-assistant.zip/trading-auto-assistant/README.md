# Trading Auto Assistant

Mobile App jo khud analyse kare aur khud trade lagaye.

## Assistant
- Name: Anime Girl AI
- Image: assets/anime_girl.png
- Style: Anime Type

## Features
- Floating Dot - Screen pe har waqt rahega
- Anime Girl - Dot dabao to larki khul jayegi
- Grok AI - Grok jaisa smart AI
- Auto Trading - EUR/USD pe UP/DOWN trade

## Tech
- Flutter
- Grok API
- Quotex (Demo pe test karo)

## Status
V1 - Complete
Made in Dina by Boss
